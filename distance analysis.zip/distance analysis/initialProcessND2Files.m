 function initialProcessND2Files(inputFolder, outputFolder)
    % PROCESSND2FILES Processes .nd2 files and saves segmented channels and their translations.
    %
    % inputFolder - Folder containing .nd2 files
    % outputFolder - Folder to save processed images
    
    % Define parameters
    numChannels = 4;  % Adjust based on your metadata
        
    % Get list of .nd2 files in input folder
    files = dir(fullfile(inputFolder, '*.nd2'));
    
    for file = files'
        filename = fullfile(inputFolder, file.name);
        fprintf('Processing file: %s\n', filename);
        data = BioformatsImage(char(filename));
        numZSlices = data.sizeZ;  % Total Z-planes in the ND2 file
        
        % Determine the most in-focus Z-slice using absolute Laplacian
        focusScores = zeros(numZSlices, 1);
        for z = 1:numZSlices
            testImage = getPlane(data, z, 4, 0.01);  % Extract a grayscale reference (e.g., DAPI channel)
            laplacianFilter = fspecial('laplacian', 0.2);
            laplacianResponse = imfilter(double(testImage), laplacianFilter, 'symmetric');
            focusScores(z) = var(laplacianResponse(:));  % Compute focus measure
        end
        
        % Select the Z-slice with the highest focus score
        [~, bestZ] = max(focusScores);
        fprintf('Best Z-slice: %d\n', bestZ);
        
        % Extract and save the best-focused Z-slice for each channel
        imagesArray = zeros(1024, 1024, numChannels, 'uint16');
        for C = 1:numChannels
            imageData = getPlane(data, bestZ, C, 1);  % Extract best Z for current channel
            imagesArray(:,:,C) = imageData;
        end
        
        % Create output folder for this file
        [~, baseName, ~] = fileparts(file.name);
        fileOutputFolder = fullfile(outputFolder, baseName);
        if ~exist(fileOutputFolder, 'dir')
            mkdir(fileOutputFolder);
        end
        
        % Save each channel as a PNG
        imwrite(imagesArray(:,:,1), fullfile(fileOutputFolder, 'DAPI.png'));
        imwrite(imagesArray(:,:,2), fullfile(fileOutputFolder, 'GC.png'));
        imwrite(imagesArray(:,:,3), fullfile(fileOutputFolder, 'rRNA.png'));
        
        % Perform segmentation
        
        % DAPI segmentation
        bwDAPI = imbinarize(imagesArray(:,:,1)); 
        bwDAPI = imfill(bwDAPI, 'holes');
        bwDAPI = bwareaopen(bwDAPI, 15000);
        %bwDAPI = imclearborder(bwDAPI);
        imwrite(bwDAPI, fullfile(fileOutputFolder, 'DAPI_segmentation.png'));
        
        % GC segmentation
        bwGC = imbinarize(imagesArray(:,:,2), 0.012);  % Adjust threshold if needed
        bwGC = bwareaopen(bwGC, 100);  % Remove small objects
        bwGC = imfill(bwGC, 'holes');  % Fill in holes
        bwGC = bwConvex(bwGC, 0.75);   % Adjust the solidity cutoff as needed
        bwGC = imgaussfilt(double(bwGC), 3);          % Gaussian blur
        bwGC = imbinarize(bwGC);                      % Convert back to binary

        imwrite(bwGC, fullfile(fileOutputFolder, 'GC_segmentation.png'));
        
        % === rRNA dot segmentation (manual clicking) ===
        % Get the image
        imgRNA = imagesArray(:,:,4);
        imgRNA = mat2gray(imgRNA); % normalize to 0–1 for display
        
        % --- Step 1: Display image and prompt user ---
        figure;
        imshow(imgRNA, []);
        title('Click on every RNA dot. Press ENTER when done.');
        
        % --- Step 2: Get user clicks ---
        [x, y] = getpts;  % user clicks on the figure; ENTER to finish
        
        % --- Step 3: Create mask of same size as image ---
        mask = false(size(imgRNA));
        
        % --- Step 4: Mark each clicked dot as a small circle ---
        dotRadius = 5;  % radius in pixels (adjust if needed)
        [cols, rows] = meshgrid(1:size(imgRNA,2), 1:size(imgRNA,1));
        
        for i = 1:length(x)
            circle = (rows - y(i)).^2 + (cols - x(i)).^2 <= dotRadius^2;
            mask = mask | circle;  % add circle to mask
        end
        imwrite(mask, fullfile(fileOutputFolder, 'RNA_segmentation.png'));


        fprintf('Processing complete for %s\n', filename);
    end
end





function new_bw = bwConvex(input_bw, Solidity_cutoff)
    % BWCONVEX Processes a binary image by replacing objects with their convex hulls 
    % if their solidity is below the specified cutoff.
    %
    % input_bw - Binary image
    % Solidity_cutoff - Threshold for solidity (objects with lower solidity will be replaced by convex hulls)
    
    [labeledImage, numObjects] = bwlabel(input_bw);
    stats = regionprops(labeledImage, 'ConvexHull', 'Solidity');
    new_bw = false(size(input_bw)); 

    for k = 1:numObjects
        convexHull = stats(k).ConvexHull;
        solidity = stats(k).Solidity;

        if solidity < Solidity_cutoff
            mask = poly2mask(convexHull(:,1), convexHull(:,2), size(input_bw, 1), size(input_bw, 2));
        else
            mask = (labeledImage == k);
        end
        
        new_bw = new_bw | mask;
    end
end



