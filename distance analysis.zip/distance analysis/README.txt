How to use:

**Make sure Bioformats Image Toolbox is installed
https://www.mathworks.com/matlabcentral/fileexchange/129249-bioformats-image-toolbox
**Make sure Image Processing Toolbox is installed



1. store all of the nd2 files into a folder
2. run "initialProcessND2Files(inputFolder, outputFolder)"
3. inspect the png masks in the output folder
4. If there are any issues, use "editAndFillMask(maskFile)" and "separateObjects(maskFile)", where maskFile is the png of the mask
5. Run "finalProcessND2Files(outputFolder)"
6. the data tables and figures will be stored in the appropriate folders


NOTE: make sure that the input folder is in the same directory as the scripts when running

NOTE: RNA spots that are not in a cell are discarded from the analysis (so you may encounter skipped RNA spot IDs)


SOMETHIGN NOT RIGHT WITH FIDNING THE NEAREST GC DOMAIN!!!!