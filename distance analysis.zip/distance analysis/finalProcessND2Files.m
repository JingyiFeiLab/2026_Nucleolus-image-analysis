function finalProcessND2Files(parentFolder)
% Parent folder containing ND2 files (subfolders)

% Get a list of subfolders (representing ND2 files) in the parent folder
nd2Folders = dir(parentFolder);
nd2Folders = nd2Folders([nd2Folders.isdir] & ~startsWith({nd2Folders.name}, '.'));

% Loop through each ND2 folder
for i = 1:numel(nd2Folders)
    nd2Folder = fullfile(parentFolder, nd2Folders(i).name);

    % Get the PNG mask files for each channel in the ND2 folder
    DAPIFile = fullfile(nd2Folder, 'DAPI_segmentation.png');
    GCFile = fullfile(nd2Folder, 'GC_segmentation.png');
    RNAFile = fullfile(nd2Folder, 'RNA_segmentation.png');

    % Load and process the required mask images
    DAPIMask = imread(DAPIFile);
    GCMask = imread(GCFile);
    RNAMask = imread(RNAFile);

    % Label cells and nucleoli
    DAPILabel = bwlabel(DAPIMask);   % Cell segmentation labels
    GCMaskLabel = bwlabel(GCMask);    % Nucleoli segmentation labels

    %% Associate nucleolus with cell
    nucleolusToCell = zeros(size(GCMask));
    gcStats = regionprops(GCMaskLabel, 'PixelIdxList');

    for j = 1:numel(gcStats)
        nucleolusPixels = gcStats(j).PixelIdxList;
        cellIndices = DAPILabel(nucleolusPixels);
        uniqueCells = unique(cellIndices);
        % Remove background label (0)
        uniqueCells(uniqueCells == 0) = [];

        if isempty(uniqueCells)
            nucleolusToCell(nucleolusPixels) = 0;
        elseif numel(uniqueCells) == 1
            nucleolusToCell(nucleolusPixels) = uniqueCells;
        else
            % Only perform histcounts if we have valid bin edges
            % (uniqueCells must be non-empty)
            cellCounts = histcounts(cellIndices, [uniqueCells; max(uniqueCells) + 1]);
            [~, maxCellIdx] = max(cellCounts);
            nucleolusToCell(nucleolusPixels) = uniqueCells(maxCellIdx);
        end
    end

    % Label the cells and nucleoli globally:
    DAPILabel = bwlabel(DAPIMask);      % Global cell labels
    GCMaskLabel = bwlabel(GCMask);       % Global nucleoli labels
    RNAMaskLabel = bwlabel(RNAMask);       % Global RNA labels

    % Create colored overlays for each mask using label2rgb.
    cellOverlay     = label2rgb(DAPILabel, 'jet',   'k', 'shuffle');    % cells in 'jet'
    nucleoliOverlay = label2rgb(GCMaskLabel, 'parula', 'k', 'shuffle');    % nucleoli in 'parula'
    rnaOverlay      = label2rgb(RNAMaskLabel, 'hot',    'k', 'shuffle');    % dfc domains in 'hot'

    % Create a figure and display the base image.
    figure;
    DAPIImage = fullfile(nd2Folder, 'DAPI.png');

    imshow(DAPIImage);  % Use the DAPI image as the base background
    hold on;
    title(sprintf('Mapping for %s', nd2Folders(i).name), 'Interpreter', 'none');

    % First, overlay the RNA mask (lowest layer)
    hRNA = imshow(rnaOverlay);
    set(hRNA, 'AlphaData', 0.3);  % adjust transparency so it doesn't overpower

    % Next, overlay the cell mask with increased opacity so cells are clearly visible
    hCell = imshow(cellOverlay);
    set(hCell, 'AlphaData', 0.6);

    % Then overlay the nucleoli mask on top
    hNuc = imshow(nucleoliOverlay);
    set(hNuc, 'AlphaData', 0.5);

    % --- Add text labels for cells (global cell IDs) ---
    cellStats = regionprops(DAPILabel, 'Centroid');
    for k = 1:numel(cellStats)
        c = cellStats(k).Centroid;
        % Label cells with their global cell ID
        text(c(1), c(2), num2str(k), 'Color', 'w', 'FontSize', 12, 'FontWeight', 'bold');
    end

    % --- Add text labels for nucleoli only if they lie inside a cell ---
    nucleoliStats = regionprops(GCMaskLabel, 'Centroid');
    for k = 1:numel(nucleoliStats)
        c = nucleoliStats(k).Centroid;
        % Check if this nucleolus falls within a cell by testing the corresponding DAPILabel pixel.
        if DAPILabel(round(c(2)), round(c(1))) > 0
            text(c(1), c(2), num2str(k), 'Color', 'y', 'FontSize', 10, 'FontWeight', 'bold');
        end
    end

    % --- Add text labels for RNA only if they lie inside a cell ---
    rnaStats = regionprops(RNAMaskLabel, 'Centroid');
    for k = 1:numel(rnaStats)
        c = rnaStats(k).Centroid;
        % Check if this rna falls within a cell by testing the corresponding DAPILabel pixel.
        if DAPILabel(round(c(2)), round(c(1))) > 0
            text(c(1), c(2), num2str(k), 'Color', 'r', 'FontSize', 10, 'FontWeight', 'bold');
        end
    end

    % Define save path for the figure
    savePath = fullfile(nd2Folder, 'overlay_figure.fig');  % Save in the ND2 folder

    % Save the figure as a .fig file
    savefig(savePath);

    % Optionally, save as a PNG for easy viewing
    saveas(gcf, fullfile(nd2Folder, 'overlay_figure.png'));


    hold off;



    %% Generate the table and save results
    tableData = generateTable(DAPIMask, GCMask, RNAMask);
    save(fullfile(nd2Folder, 'cell_data.mat'), 'tableData');
end
end





function tableData = generateTable(DAPIMask, GCmask, rRNA_bw)
% generateTable associates RNA spots with nucleoli and cells
%
% Inputs:
%   DAPIMask : Binary or labeled mask of cells
%   GCmask   : Binary or labeled mask of nucleoli (GC domains)
%   rRNA_bw  : Binary mask of RNA fluorescence spots
%
% Output table columns:
%   [CellID, NucleolusID, RNAX, RNAY, DistanceToGC]

%% --- Label all masks ---
DAPILabel = bwlabel(DAPIMask);
GCLabel   = bwlabel(GCmask);
spotProps = regionprops(rRNA_bw, 'Centroid');

if isempty(spotProps)
    warning('No RNA spots detected.');
    tableData = cell2table(cell(0,5), 'VariableNames', ...
        {'CellID','NucleolusID','RNAID','DistanceToGC','RNASpotX','RNASpotY','PeripherySpotX','PeripherySpotY','GCCenterX','GCCenterY'});
    return;
end

spotXY = vertcat(spotProps.Centroid);

%% --- Precompute region information ---
statsCell = regionprops(DAPILabel, 'PixelIdxList', 'Centroid');
statsGC   = regionprops(GCLabel, 'PixelIdxList', 'Centroid');

% Map each GC to its parent cell
numGCs = numel(statsGC);
gcToCell = zeros(numGCs,1);

for i = 1:numGCs
    gcMask = false(size(GCLabel));
    gcMask(statsGC(i).PixelIdxList) = true;

    parentIDs = DAPILabel(gcMask);
    parentIDs = parentIDs(parentIDs > 0);
    if isempty(parentIDs)
        gcToCell(i) = 0; % unassigned
    else
        gcToCell(i) = mode(parentIDs);
    end
end

%% --- Build KD-tree of GC periphery points for fast distance calculation ---
gcPerimeters = cell(numGCs,1);
gcCentroids  = zeros(numGCs,2);

for i = 1:numGCs
    gcMask = false(size(GCLabel));
    gcMask(statsGC(i).PixelIdxList) = true;
    gcCentroids(i,:) = statsGC(i).Centroid;

    perim = bwperim(gcMask);
    [r,c] = find(perim);
    gcPerimeters{i} = [c, r]; % x,y
end

%% --- Loop over RNA spots ---
tableRows = {};
numSpots = size(spotXY,1);

for s = 1:numSpots
    x = spotXY(s,1);
    y = spotXY(s,2);

    % Find parent cell of RNA spot
    cellID = DAPILabel(round(y), round(x));
    if cellID == 0
        % Outside any cell
        continue;
    end

    gcIdx = find(gcToCell == cellID);
    if isempty(gcIdx)
        continue;
    end

    % --- Compute distance to closest GC in same cell ---
    minDist = inf;
    closestGC = NaN;
    closestPeriphery = [NaN NaN];
    gcCenterPoint = [NaN NaN];

    for idx = gcIdx'
        perimPoints = gcPerimeters{idx};
        if isempty(perimPoints)
            continue;
        end

        % Compute distances to each periphery point
        dists = sqrt((x - perimPoints(:,1)).^2 + (y - perimPoints(:,2)).^2);
        [dToPeriphery, minIdx] = min(dists);

        % For reference: distance from GC centroid to its periphery
        dCenterToPeriphery = sqrt(min((gcCentroids(idx,1) - perimPoints(:,1)).^2 + ...
                                      (gcCentroids(idx,2) - perimPoints(:,2)).^2));

        % Update minimum and record corresponding periphery and center points
        if abs(dToPeriphery) < abs(minDist)
            minDist = dToPeriphery;
            closestGC = idx;
            closestPeriphery = perimPoints(minIdx,:);       % (x,y) of closest periphery point
            gcCenterPoint = gcCentroids(idx,:);             % (x,y) of GC center
        end
    end

    if ~isnan(closestGC)
        tableRows(end+1, :) = {cellID, closestGC, s, minDist, x, y, closestPeriphery(1),closestPeriphery(2),gcCenterPoint(1),gcCenterPoint(2)}; %#ok<AGROW>
    end
    
    
end

%% --- Convert to table ---
if isempty(tableRows)
    tableData = cell2table(cell(0,10), 'VariableNames', ...
        {'CellID','NucleolusID','RNAID','DistanceToGC','RNASpotX','RNASpotY','PeripherySpotX','PeripherySpotY','GCCenterX','GCCenterY'});
else
    tableData = cell2table(tableRows, 'VariableNames', ...
        {'CellID','NucleolusID','RNAID','DistanceToGC','RNASpotX','RNASpotY','PeripherySpotX','PeripherySpotY','GCCenterX','GCCenterY'});
end

end

