function initialProcessND2Files(inputFolder, outputFolder)
% initialProcessND2Files Processes .nd2 files and saves segmented channels and their translations.
%
%   initialProcessND2Files(inputFolder, outputFolder) processes each .nd2 file
%   in the inputFolder, extracts the best-focused Z-slice for each channel,
%   subtracts background, performs segmentation, and saves the output images and
%   background values in the outputFolder.
%
%   Parameters:
%       inputFolder  - Folder containing .nd2 files.
%       outputFolder - Folder where processed images and data are saved.

    %% Define parameters
    numChannels = 4;    % Adjust based on your metadata
    greenChannel = 3;   % Assuming green is channel 3

    offsetX = 0;
    offsetY = 0;        % Pixel shift in Y direction

    %% Get list of .nd2 files in the input folder
   
    files = dir(fullfile(inputFolder, '*.nd2'));
    
    for file = files'
        filename = fullfile(inputFolder, file.name);
        fprintf('Processing file: %s\n', filename);
        
        % Read file using Bioformats
        data = BioformatsImage(char(filename));
        numZSlices = data.sizeZ;  % Total number of Z-slices
        

        %% Determine the most in-focus Z-slice using an absolute Laplacian filter
        focusScores = zeros(numZSlices, 1);

        for z = 1:(numZSlices)
            % Extract a grayscale reference from a chosen channel (e.g., DAPI)
            testImage = getPlane(data, z, 3, 1);
            laplacianFilter = fspecial('laplacian', 0.2);
            laplacianResponse = imfilter(double(testImage), laplacianFilter, 'symmetric');
            focusScores(z) = var(laplacianResponse(:));
        end
        
        [~, bestZ] = max(focusScores);
        fprintf('Best Z-slice: %d\n', bestZ);
        
        %% Extract the best-focused Z-slice for each channel
        % Preallocate an array for the image stack (assumes 1024x1024 images)
        imagesArray = zeros(1024, 1024, numChannels, 'uint16');
        for C = 1:numChannels
            imageData = getPlane(data, bestZ, C, 1);
            
            % Apply translation to the green channel
            if C == greenChannel
                imageData = imtranslate(imageData, [offsetX, offsetY]);
            end
            imagesArray(:,:,C) = imageData;
        end
        
        %% Create output folder for the current file
        [~, baseName, ~] = fileparts(file.name);
        fileOutputFolder = fullfile(outputFolder, baseName);
        if ~exist(fileOutputFolder, 'dir')
            mkdir(fileOutputFolder);
        end
        
        %% Background subtraction for each channel
        [DAPIImage, DAPIBackground]   = subtractBackground(imagesArray(:,:,1));
        [GCImage, GCBackground]       = subtractBackground(imagesArray(:,:,2));
        [DFCImage, DFCBackground]     = subtractBackground(imagesArray(:,:,3));
        [rRNAImage, rRNABackground]   = subtractBackground(imagesArray(:,:,4));
        
        %% Save background values to a text file
        bgFilename = fullfile(outputFolder, 'background_values.txt');
        fileID = fopen(bgFilename, 'w'); % Open file for writing
        fprintf(fileID, 'DAPI Background: %f\n', DAPIBackground);
        fprintf(fileID, 'GC Background: %f\n', GCBackground);
        fprintf(fileID, 'DFC Background: %f\n', DFCBackground);
        fprintf(fileID, 'rRNA Background: %f\n', rRNABackground);
        fclose(fileID);
        
        %% Save each channel as PNG images
        imwrite(DAPIImage, fullfile(fileOutputFolder, 'DAPI.png'));
        imwrite(GCImage, fullfile(fileOutputFolder, 'GC.png'));
        imwrite(DFCImage, fullfile(fileOutputFolder, 'DFC.png'));
        imwrite(rRNAImage, fullfile(fileOutputFolder, 'rRNA.png'));
        
        %% Perform segmentation
        

        % DAPI segmentation
        bwDAPI = imbinarize(imagesArray(:,:,1)); 
        bwDAPI = imfill(bwDAPI, 'holes');
        bwDAPI = bwareaopen(bwDAPI, 7000);
        bwDAPI = imgaussfilt(double(bwDAPI), 3); % Apply Gaussian blur
        bwDAPI = imbinarize(bwDAPI);            % Convert back to binary
        bwDAPI = imclearborder(bwDAPI);
        imwrite(bwDAPI, fullfile(fileOutputFolder, 'DAPI_segmentation.png'));
        
        
        % GC segmentation
        
        bwGC = imbinarize(imagesArray(:,:,2), 0.012);  % Adjust threshold as needed
        bwGC = bwareaopen(bwGC, 100);                 % Remove small objects
        bwGC = imfill(bwGC, 'holes'); 
        % Fill holes
        bwGC = bwConvex(bwGC, 0.75);                  % Replace low-solidity objects with convex hulls
        bwGC = imgaussfilt(double(bwGC), 3);          % Gaussian blur
        bwGC = imbinarize(bwGC);                      % Convert back to binary
        imwrite(bwGC, fullfile(fileOutputFolder, 'GC_segmentation.png'));
        

        % DFC segmentation%
        bwDFC = imbinarize(imagesArray(:,:,3), adaptthresh(imagesArray(:,:,3), 0.1, 'NeighborhoodSize', 35));
        bwDFC = bwareaopen(bwDFC, 20);
        imwrite(bwDFC, fullfile(fileOutputFolder, 'DFC_segmentation.png'));
        

        % DFC border segmentation
        %make convolution matrix
        kernel = ones(3,3);   
        kernel(2,2) = 0; 

        touching = conv2(double(bwDFC), kernel, 'same') > 0;

        bwDFC_border = touching & ~bwDFC;

        imwrite(bwDFC_border, fullfile(fileOutputFolder, 'DFC_border_segmentation.png'));

        
        fprintf('Processing complete for %s\n', filename);





    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function new_bw = bwConvex(input_bw, solidityCutoff)
% bwConvex Replaces objects in a binary image with their convex hulls if
%          their solidity is below a specified cutoff.
%
%   new_bw = bwConvex(input_bw, solidityCutoff)
%
%   Parameters:
%       input_bw      - Binary image.
%       solidityCutoff- Threshold for solidity. Objects with solidity below
%                       this cutoff are replaced by their convex hull.
%
%   Returns:
%       new_bw - Processed binary image.

    [labeledImage, numObjects] = bwlabel(input_bw);
    stats = regionprops(labeledImage, 'ConvexHull', 'Solidity');
    new_bw = false(size(input_bw)); 

    for k = 1:numObjects
        convexHull = stats(k).ConvexHull;
        solidity = stats(k).Solidity;
        
        if solidity < solidityCutoff
            mask = poly2mask(convexHull(:,1), convexHull(:,2), size(input_bw, 1), size(input_bw, 2));
        else
            mask = (labeledImage == k);
        end
        new_bw = new_bw | mask;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [modifiedImage, backgroundValue] = subtractBackground(image)
% subtractBackground Removes background intensity from an image using a Gaussian fit.
%
%   [modifiedImage, backgroundValue] = subtractBackground(image)
%
%   Parameters:
%       image - Grayscale image matrix.
%
%   Returns:
%       modifiedImage - Background-subtracted image (ensuring no negative values).
%       backgroundValue - Estimated background intensity (Gaussian mean).

    % Compute histogram
    numBins = 256;  
    [counts, binEdges] = histcounts(image(:), numBins);
    binCenters = (binEdges(1:end-1) + binEdges(2:end)) / 2;
    
    % Initial guess for Gaussian parameters: [amplitude, mean, stddev]
    [maxCount, maxIdx] = max(counts);
    initialGuess = [maxCount, binCenters(maxIdx), 20];
    
    % Define Gaussian function
    gaussFunc = @(params, x) params(1) * exp(-(x - params(2)).^2 / (2 * params(3)^2));
    
    % Fit Gaussian to histogram data using nonlinear least squares
    options = optimset('Display', 'off');
    params = lsqcurvefit(gaussFunc, initialGuess, binCenters, counts, [], [], options);
    
    % Background value is the mean of the fitted Gaussian
    backgroundValue = params(2);
    
    % Subtract background, ensuring no negative values
    modifiedImage = max(image - backgroundValue, 0);
end
