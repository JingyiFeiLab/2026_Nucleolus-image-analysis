function filledMask = editAndFillMask(maskFile)
    % Read the original mask from the given file
    originalMask = imread(maskFile);
    
    % Create a figure and display the original mask
    hFig = figure; 
    ax = axes('Parent', hFig); 
    imshow(originalMask, 'Parent', ax);
    title(ax, 'Draw lines to edit the mask. Click "Done" when finished.');
    
    % Create a "Done" button that allows the user to continue without closing the window
    doneButton = uicontrol('Style', 'pushbutton', 'String', 'Done', ...
        'Position', [20 20 60 30], 'Callback', @(src, event) uiresume(hFig));

    % Initialize the updated mask
    updatedMask = originalMask;

    % Allow multiple edits
    while isvalid(hFig) % Check if the figure is still open
        hLine = drawline(ax);
        
        % If the user presses "Done", exit the loop
        if ~isvalid(hFig)
            break;
        end

        % Convert the drawn line into a binary mask and update
        lineMask = createMask(hLine);
        updatedMask = updatedMask | lineMask;
    end

    % Fill enclosed holes in the updated mask
    filledMask = imfill(updatedMask, 'holes');

    % Close the figure if still open
    if isvalid(hFig)
        close(hFig);
    end

    % Display the final filled mask
    figure, imshow(filledMask), title('Final Filled Mask');

    % Ask the user to confirm overwriting the original file
    choice = questdlg('Do you want to overwrite the original mask?', ...
        'Save Mask', ...
        'Yes', 'No', 'Yes');
    
    % If the user selects 'Yes', overwrite the original file
    if strcmp(choice, 'Yes')
        imwrite(filledMask, maskFile);
        disp('Mask saved successfully!');
    else
        disp('Mask not saved.');
    end
end


