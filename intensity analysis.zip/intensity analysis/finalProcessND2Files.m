function finalProcessND2Files(parentFolder)
% finalProcessND2Files Processes ND2 files stored in subfolders of the parent folder.
%
%   finalProcessND2Files(parentFolder) iterates over each subfolder (each representing
%   an ND2 file), processes segmentation masks and intensity images, associates nucleoli
%   with cells and DFC domains with nucleoli, creates overlay figures, and saves a data
%   table containing computed metrics.
%
%   Parameters:
%       parentFolder - Path to the parent folder containing ND2 file subfolders.

    % Get list of subfolders (each representing an ND2 file)
    nd2Folders = dir(parentFolder);
    nd2Folders = nd2Folders([nd2Folders.isdir] & ~startsWith({nd2Folders.name}, '.'));

    % Process each ND2 folder
    for i = 1:numel(nd2Folders)
        nd2Folder = fullfile(parentFolder, nd2Folders(i).name);

        %% Read Segmentation Mask Files
        DAPIFile = fullfile(nd2Folder, 'DAPI_segmentation.png');
        GCFile   = fullfile(nd2Folder, 'GC_segmentation.png');
        DFCFile  = fullfile(nd2Folder, 'DFC_segmentation.png');
        DFCBorderFile = fullfile(nd2Folder, 'DFC_border_segmentation.png');

        DAPIMask = imread(DAPIFile);
        GCMask   = imread(GCFile);
        DFCMask  = imread(DFCFile);
        DFCBorderMask = imread(DFCBorderFile);

        %% Read Intensity Images
        DAPIImage = imread(fullfile(nd2Folder, 'DAPI.png'));
        GCImage   = imread(fullfile(nd2Folder, 'GC.png'));
        DFCImage  = imread(fullfile(nd2Folder, 'DFC.png'));
        rRNAImage = imread(fullfile(nd2Folder, 'rRNA.png'));

        %% Label the Segmentation Masks
        DAPILabel   = bwlabel(DAPIMask);   % Cells
        GCMaskLabel = bwlabel(GCMask);      % Nucleoli
        DFCMaskLabel= bwlabel(DFCMask);      % DFC regions

        % Save labeled images for visualization
        saveLabeledImage(DAPILabel, fullfile(nd2Folder, 'DAPI_Mask_labeled.png'));
        saveLabeledImage(GCMaskLabel, fullfile(nd2Folder, 'GC_Mask_labeled.png'));
        saveLabeledImage(DFCMaskLabel, fullfile(nd2Folder, 'DFC_Mask_labeled.png'));

        %% Associate Nucleoli with Cells
        nucleolusToCell = zeros(size(GCMask));
        gcStats = regionprops(GCMaskLabel, 'PixelIdxList');

        for j = 1:numel(gcStats)
            nucleolusPixels = gcStats(j).PixelIdxList;
            cellIndices = DAPILabel(nucleolusPixels);
            uniqueCells = unique(cellIndices);
            uniqueCells(uniqueCells == 0) = [];  % Remove background

            if isempty(uniqueCells)
                nucleolusToCell(nucleolusPixels) = 0;
            elseif numel(uniqueCells) == 1
                nucleolusToCell(nucleolusPixels) = uniqueCells;
            else
                cellCounts = histcounts(cellIndices, [uniqueCells; max(uniqueCells) + 1]);
                [~, maxCellIdx] = max(cellCounts);
                nucleolusToCell(nucleolusPixels) = uniqueCells(maxCellIdx);
            end
        end

        %% Associate DFC Domains with Nucleoli
        DFCToGCMap = zeros(size(DFCMask));
        DFCLabel = bwlabel(DFCMask);
        dfcStats = regionprops(DFCLabel, 'PixelIdxList');

        for k = 1:numel(dfcStats)
            dfcPixels = dfcStats(k).PixelIdxList;
            nucleolusIndices = GCMaskLabel(dfcPixels);
            uniqueNucleoli = unique(nucleolusIndices);
            uniqueNucleoli(uniqueNucleoli == 0) = [];  % Remove background

            if isempty(uniqueNucleoli)
                DFCToGCMap(dfcPixels) = 0;
            elseif numel(uniqueNucleoli) == 1
                DFCToGCMap(dfcPixels) = uniqueNucleoli;
            else
                nucCounts = histcounts(nucleolusIndices, [uniqueNucleoli; max(uniqueNucleoli) + 1]);
                [~, maxIdx] = max(nucCounts);
                DFCToGCMap(dfcPixels) = uniqueNucleoli(maxIdx);
            end
        end

        %% Create Overlay Figure for Visualization
        createOverlayFigure(DAPIImage, DAPIMask, GCMask, DFCToGCMap, nd2Folder);

        % Generate the table data
        tableData = generateTable(DAPILabel, GCMaskLabel, DFCMaskLabel, DFCBorderMask, ...
                                  DAPIImage, GCImage, DFCImage, rRNAImage);
        
        % Define the Excel file path
        excelFilePath = fullfile(parentFolder, 'cell_data.xlsx');
        
        % Write the table to an Excel file
        writetable(tableData, excelFilePath, 'Sheet', nd2Folders(i).name, 'WriteMode', 'overwritesheet');
        
        % Notify the user
        fprintf('Table data saved to Excel file: %s\n', excelFilePath);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function tableData = generateTable(DAPIMask, nucleolusToCell, DFCToGCMap, DFCBorderMask, ...
                                   DAPIImage, GCImage, DFCImage, rRNAImage)
% generateTable Generates a table of cell and nucleolus metrics.
%
%   Parameters:
%       DAPIMask       - Binary or labeled image for cell segmentation.
%       nucleolusToCell- Labeled image mapping nucleoli to cells.
%       DFCToGCMap     - Image mapping DFC domain pixels to nucleoli.
%       DAPIImage      - Intensity image for cell analysis.
%       GCImage        - Intensity image for nucleolus analysis.
%       DFCImage       - Intensity image for DFC analysis.
%       rRNAImage      - Intensity image for rRNA analysis.
%
%   Returns:
%       tableData - A MATLAB table with computed metrics.

    tableRows = {};
    cellLabels = unique(DAPIMask);
    cellLabels(cellLabels == 0) = [];  % Remove background


    for cellID = cellLabels'
        cellMask = (DAPIMask == cellID);
        nucleolusIDs = unique(nucleolusToCell(cellMask));
        nucleolusIDs(nucleolusIDs == 0) = [];
        rRNAAvgIntensityDAPI = mean(rRNAImage(cellMask));

        if isempty(nucleolusIDs)
            continue;
        end

        cellArea = sum(cellMask(:));
        cellAvgIntensity = mean(DAPIImage(cellMask));

        for nucID = nucleolusIDs'
            nucleolusMask = (nucleolusToCell == nucID);
            if ~any(cellMask & nucleolusMask)
                continue;
            end

            nucleolusArea = sum(nucleolusMask(:));
            nucleolusAvgIntensity = mean(GCImage(nucleolusMask));
            rRNAnucelolusAvgIntensity = mean(rRNAImage(nucleolusMask));

            % Use regionprops to calculate circularity for the nucleolus
            stats = regionprops(nucleolusMask, 'Area', 'Perimeter', 'Circularity');
            if ~isempty(stats)
                circularity = stats.Circularity;
            else
                circularity = NaN;
            end

            % DFC region analcysis
            dfcIDs = unique(DFCToGCMap(nucleolusMask));
            dfcIDs(dfcIDs == 0) = [];

            if isempty(dfcIDs)
                dfcIDsStr = 'None';
                dfcArea = NaN;
                dfcAvgIntensity = NaN;
                rRNA_DFC_AvgIntensity = NaN;
                DFCtoGC_Area_Ratio = NaN;
                dfcBorderArea = NaN;
                rRNAdfcBorderAvgIntensity = NaN;
            else
                dfcIDsStr = strjoin(arrayfun(@num2str, dfcIDs, 'UniformOutput', false), ',');
                dfcMask = ismember(DFCToGCMap, dfcIDs);
                dfcArea = nnz(dfcMask);
                dfcAvgIntensity = mean(DFCImage(dfcMask));
                rRNA_DFC_AvgIntensity = mean(rRNAImage(dfcMask));

                DFCtoGC_Area_Ratio = dfcArea / nucleolusArea;

                % Border pixels that touch this DFC domain
                % Use 8-connected adjacency
                borderPixels = find(DFCBorderMask);
                [borderY, borderX] = ind2sub(size(DFCBorderMask), borderPixels);
        
                % For each border pixel, check if it neighbors the DFC domain 
                neighborOffsets = [-1 -1; -1 0; -1 1;
                                    0 -1;        0 1;
                                    1 -1;  1 0;  1 1];
        
                borderTouchingDFC = false(size(borderPixels));
                for k = 1:numel(borderPixels)
                    y = borderY(k);
                    x = borderX(k);
                    for n = 1:size(neighborOffsets,1)
                        ny = y + neighborOffsets(n,1);
                        nx = x + neighborOffsets(n,2);
                        if ny >= 1 && ny <= size(dfcMask,1) && nx >= 1 && nx <= size(dfcMask,2)
                            if dfcMask(ny,nx)
                                borderTouchingDFC(k) = true;
                                break
                            end
                        end
                    end
                end
        
                % Mask of border pixels associated with this DFC
                dfcBorderMask = false(size(dfcMask));
                dfcBorderMask(borderPixels(borderTouchingDFC)) = true;
        
                % Border stats            
                dfcBorderArea = nnz(dfcBorderMask);
                
                if dfcBorderArea > 0
                    rRNAdfcBorderAvgIntensity = mean(rRNAImage(dfcBorderMask));
                    
                else
                    rRNAdfcBorderAvgIntensity = NaN;
                end
        
            end

            tableRows(end+1, :) = {cellID, nucID, dfcIDsStr, cellArea, nucleolusArea, dfcArea, dfcBorderArea, ...
                cellAvgIntensity, nucleolusAvgIntensity, dfcAvgIntensity, rRNAnucelolusAvgIntensity, rRNA_DFC_AvgIntensity, ...
                rRNAdfcBorderAvgIntensity, DFCtoGC_Area_Ratio, circularity, rRNAAvgIntensityDAPI};
        end
    end

    if(isempty(tableRows))
        tableRows(1, :) = {0, 0, 0, 0, 0, 0, 0, ...
                0, 0, 0, 0, 0, ...
                0, 0};
    end

    tableData = cell2table(tableRows, 'VariableNames', ...
        {'CellID', 'NucleolusID', 'DFC_ID', 'CellArea', 'NucleolusArea', 'DFCArea', 'DFCBorderArea', ...
         'CellAvgIntensity', 'NucleolusAvgIntensity', 'DFCAvgIntensity', 'rRNA_GC_AvgIntensity', ...
         'rRNA_DFC_AvgIntensity', 'rRNA_DFCborder_AvgIntensity', 'DFCtoGC_Area_Ratio', 'GCCircularity', 'rRNAAvgIntensityDAPI'});
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function saveLabeledImage(labelMask, outputFilename)
% saveLabeledImage Saves a labeled mask as an RGB image with overlaid label numbers.
%
%   Parameters:
%       labelMask      - Labeled mask (e.g., from bwlabel).
%       outputFilename - Path to save the labeled PNG image.

    % Convert the labeled mask to an RGB image
    labeledRGB = label2rgb(labelMask, 'jet', 'k', 'shuffle');
    
    % Get region properties (centroids)
    stats = regionprops(labelMask, 'Centroid');
    
    % Create a figure (invisible to avoid displaying it)
    figure('Visible', 'off');
    imshow(labeledRGB);
    hold on;
    
    % Overlay label numbers on the image
    for i = 1:numel(stats)
        if ~isempty(stats(i).Centroid)
            position = stats(i).Centroid;
            text(position(1), position(2), num2str(i), ...
                'Color', 'white', ... % Use 'white' or [1 1 1]
                'FontSize', 8, ...
                'FontWeight', 'bold', ...
                'HorizontalAlignment', 'center');
        end
    end
    
    % Save the figure as a PNG file
    exportgraphics(gcf, outputFilename, 'Resolution', 300);
    
    % Close the figure
    close(gcf);
    
    % Notify the user
    fprintf('Labeled image saved as %s\n', outputFilename);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function createOverlayFigure(DAPIImage, DAPIMask, GCMask, DFCToGCMap, outputFolder)
% createOverlayFigure Generates an overlay of cells, nucleoli, and DFC domains.
%
%   Parameters:
%       DAPIImage   - Grayscale DAPI image (background).
%       DAPIMask    - Cell segmentation mask.
%       GCMask      - Nucleoli segmentation mask.
%       DFCToGCMap  - DFC domain segmentation map.
%       outputFolder- Folder where the overlay figure will be saved.
%
%   The function saves the overlay as both a FIG and PNG file.

    DAPILabel = bwlabel(DAPIMask);
    GCMaskLabel = bwlabel(GCMask);
    DFCLabel = bwlabel(DFCToGCMap);

    cellOverlay = label2rgb(DAPILabel, 'jet', 'k', 'shuffle');
    nucleoliOverlay = label2rgb(GCMaskLabel, 'parula', 'k', 'shuffle');
    dfcOverlay = label2rgb(DFCLabel, 'hot', 'k', 'shuffle');

    figure;
    imshow(DAPIImage);
    hold on;
    title('Overlay Visualization', 'Interpreter', 'none');

    % Overlay DFC (lowest layer)
    hDFC = imshow(dfcOverlay);
    set(hDFC, 'AlphaData', 0.3);

    % Overlay cell segmentation
    hCell = imshow(cellOverlay);
    set(hCell, 'AlphaData', 0.6);

    % Overlay nucleoli segmentation
    hNuc = imshow(nucleoliOverlay);
    set(hNuc, 'AlphaData', 0.5);

    % Add cell labels for cells with nucleoli
    cellStats = regionprops(DAPILabel, 'Area', 'Centroid');
    for k = 1:numel(cellStats)
        c = cellStats(k).Centroid;
        cellMask = (DAPILabel == k);
        intersection = cellMask & (GCMaskLabel > 0);
        if any(intersection(:))
            nucleolusIDsInCell = unique(GCMaskLabel(cellMask & (GCMaskLabel > 0)));
            if any(nucleolusIDsInCell > 0)
                text(c(1), c(2), num2str(k), 'Color', 'w', 'FontSize', 12, 'FontWeight', 'bold');
            end
        end
    end

    % Add nucleoli labels (only if inside a cell)
    nucleoliStats = regionprops(GCMaskLabel, 'Centroid');
    for k = 1:numel(nucleoliStats)
        c = nucleoliStats(k).Centroid;
        if DAPILabel(round(c(2)), round(c(1))) > 0 && GCMaskLabel(round(c(2)), round(c(1))) > 0
            text(c(1), c(2), num2str(k), 'Color', 'y', 'FontSize', 10, 'FontWeight', 'bold');
        end
    end

    % Ensure output folder exists
    if ~exist(outputFolder, 'dir')
        mkdir(outputFolder);
    end

    figPath = fullfile(outputFolder, 'overlay_figure.fig');
    pngPath = fullfile(outputFolder, 'overlay_figure.png');
    savefig(figPath);
    saveas(gcf, pngPath);

    fprintf('Overlay figure saved to %s and %s\n', figPath, pngPath);
    hold off;
end
