function separatedMask = separateObjects(maskFile)
    % Read the original mask from the given file
   
    originalMask = imread(maskFile);
    
    % Default line thickness if not specified
    lineThickness = 3; % Adjust this for thicker or thinner lines
    
    % Create a figure and display the original mask
    hFig = figure;
    ax = axes('Parent', hFig);
    imshow(originalMask, 'Parent', ax);
    title(ax, 'Draw lines to separate objects. Click "Done" when finished.');
    
    % Create a "Done" button that allows the user to continue without closing the window
    doneButton = uicontrol('Style', 'pushbutton', 'String', 'Done', ...
        'Position', [20 20 60 30], 'Callback', @(src, event) uiresume(hFig));

    % Initialize the updated mask
    updatedMask = originalMask;

    % Structuring element for dilation (controls line thickness)
    se = strel('disk', lineThickness);

    % Allow multiple edits
    while isvalid(hFig) % Check if the figure is still open
        hLine = drawline(ax);

        % If the user presses "Done", exit the loop
        if ~isvalid(hFig)
            break;
        end

        % Convert the drawn line into a binary mask
        lineMask = createMask(hLine);

        % Make the line thicker using morphological dilation
        thickLineMask = imdilate(lineMask, se);

        % Subtract the thickened line from the original mask (splitting objects)
        updatedMask = updatedMask & ~thickLineMask;
    end

    % Fill any enclosed holes in the updated mask
    separatedMask = imfill(updatedMask, 'holes');

    % Close the figure if still open
    if isvalid(hFig)
        close(hFig);
    end

    % Display the final separated mask
    figure, imshow(separatedMask), title('Mask with Separated Objects');

    % Ask the user to confirm overwriting the original file
    choice = questdlg('Do you want to overwrite the original mask?', ...
        'Save Mask', ...
        'Yes', 'No', 'Yes');
    
    % If the user selects 'Yes', overwrite the original file
    if strcmp(choice, 'Yes')
        imwrite(separatedMask, maskFile);
        disp('Mask saved successfully!');
    else
        disp('Mask not saved.');
    end
end
