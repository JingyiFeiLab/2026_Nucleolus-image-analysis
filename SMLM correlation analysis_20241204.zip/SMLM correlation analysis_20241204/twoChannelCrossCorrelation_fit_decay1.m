function [c_fit, fh] = twoChannelCrossCorrelation_fit_decay1(c,fit_range)
	if nargin<2
		fit_range.GG = [0 max(c.c1_r)];
		fit_range.RR = [0 max(c.c1_r)];
		fit_range.GR = [0 max(c.c1_r)];
	end
	fit_index.GG = c.c1_r >= fit_range.GG(1) & c.c1_r <= fit_range.GG(2);
	fit_index.RR = c.c1_r >= fit_range.RR(1) & c.c1_r <= fit_range.RR(2);
	fit_index.GR = c.c1_r >= fit_range.GR(1) & c.c1_r <= fit_range.GR(2);
        
    c_fit.decay1_fitresult_GRsub = fit(c.c1_r(fit_index.GR),c.c1_GR_sub(fit_index.GR), 'exp1');	% [a b] in y = a*exp(-bx)
    c_fit.decay1_coeff_GRsub = coeffvalues(c_fit.decay1_fitresult_GRsub);

	fh = figure; 
	tiledlayout('flow','TileSpacing','tight','Padding','tight');
	nexttile;	plot(c.c1_r, c.c1_GR_sub,'b.'); hold on;
				plot(c_fit.decay1_fitresult_GRsub,'b');
				plot(c.c1_r(fit_index.GR), c.c1_GR_sub(fit_index.GR),'bo','MarkerFaceColor','b');

				yline(0);
				xlabel('r pixel'); ylabel('corr [0,1]'); 
				title('GR radial - subtracted');

	figureSetting(fh,[1400 800]);
end