function fh = twoChannelCrossCorrelation_plot(c)

	fh = figure; 
	tiledlayout(4,5,'TileSpacing','tight','Padding','tight');
	
	%% row 1: plotting ROI
	I_display(:,:,1) = zeros(size(c.I_G));
	I_display(:,:,2) = imadjust(c.I_G);
	I_display(:,:,3) = zeros(size(c.I_G));
	nexttile();	imshow(I_display); title('G channel');

	I_display(:,:,1) = imadjust(c.I_R);
	I_display(:,:,2) = zeros(size(c.I_G));
	I_display(:,:,3) = zeros(size(c.I_G));
	nexttile();	imshow(I_display); title('R channel');

	I_display(:,:,1) = imadjust(c.I_R);
	I_display(:,:,2) = imadjust(c.I_G);
	I_display(:,:,3) = zeros(size(c.I_G));
	nexttile();	imshow(I_display); title('GR overlay');
				text(2,2,['pearson: ' num2str(c.pearson) ' | manders: ' num2str(c.manders)],"Color",'y','VerticalAlignment','top');
				

	I_display(:,:,1) = imadjust(c.I_R);
	I_display(:,:,2) = imadjust(c.I_G_rand);
	I_display(:,:,3) = zeros(size(c.I_G));
	nexttile();	imshow(I_display);	title('R+G\_rand');

	I_display(:,:,1) = imadjust(c.I_R_rand);
	I_display(:,:,2) = imadjust(c.I_G);
	I_display(:,:,3) = zeros(size(c.I_G));
	nexttile();	imshow(I_display);	title('G+R\_rand');
						
	

	%% row 2: non-normalized corss correlation - avoid.
	x0 = (size(c.c2_norm,2)+1)/2; % if image is 5 pixels, center is 3 (1+5)/2, if image has 6 pixels, center is 3.5 (1+6)/2
	y0 = (size(c.c2_norm,1)+1)/2;
	% d_disp = 50;	% pixel for displaying correlation functions
	d_disp = min(size(c.I_G));	% pixel for displaying correlation functions

	nexttile;	imagesc(c.c2_GG); axis equal tight; hold on;
				plot(x0,y0,'+');
				for rr=10:10:d_disp
					viscircles([x0 y0], rr, 'color','k','EnhanceVisibility',0,'LineWidth',1,'LineStyle',':');
				end
				% xlim([x0-d_disp x0+d_disp]); ylim([y0-d_disp y0+d_disp]);
				title('GG corr2'); colorbar;

	nexttile;	imagesc(c.c2_RR); axis equal tight; hold on;
				plot(x0,y0,'+'); 
				for rr=10:10:d_disp
					viscircles([x0 y0], rr, 'color','k','EnhanceVisibility',0,'LineWidth',1,'LineStyle',':');
				end
				% xlim([x0-d_disp x0+d_disp]); ylim([y0-d_disp y0+d_disp]);
				title('RR corr2'); colorbar;

	nexttile;	imagesc(c.c2_GR); axis equal tight;  hold on;
				plot(x0,y0,'+');
				for rr=10:10:d_disp
					viscircles([x0 y0], rr, 'color','k','EnhanceVisibility',0,'LineWidth',1,'LineStyle',':');
				end
				% xlim([x0-d_disp x0+d_disp]); ylim([y0-d_disp y0+d_disp]);
				title('GR corr2'); colorbar;
	
	nexttile;	plot(c.c1_r_all,c.c1_GR_all,'color',[0.8 0.8 0.8]); hold on; 
				plot(c.c1_r,c.c1_GR,'b'); 
				xlabel('r pixel'); ylabel('corr [0,1]');
				title('GR radial');
	nexttile;	plot(c.c1_r,c.c1_GG,'g');  hold on; 
				plot(c.c1_r,c.c1_RR,'r');
				plot(c.c1_r,c.c1_GR,'b');
				xlabel('r pixel'); ylabel('corr [0,1]');
				% lgd = legend(['GG: ' num2str(c.decay_GG)], ['RR: ' num2str(c.decay_RR)], ['GR: ' num2str(c.decay_GR)]); 
				% 	lgd.Layout.Tile = 'east';
				% 	title(lgd,'non-norm decay length [px]');
				title('radial');

	%% row 3: normalized correlation - use this one
	nexttile;	imagesc(c.c2_GG_n); axis equal tight; hold on;
				plot(x0,y0,'+');
				for rr=10:10:d_disp
					viscircles([x0 y0], rr, 'color','k','EnhanceVisibility',0,'LineWidth',1,'LineStyle',':');
				end
				% xlim([x0-d_disp x0+d_disp]); ylim([y0-d_disp y0+d_disp]);
				title('GG norm'); colorbar; %clim([-1 1])

	nexttile;	imagesc(c.c2_RR_n); axis equal tight;  hold on;
				plot(x0,y0,'+');
				for rr=10:10:d_disp
					viscircles([x0 y0], rr, 'color','k','EnhanceVisibility',0,'LineWidth',1,'LineStyle',':');
				end
				% xlim([x0-d_disp x0+d_disp]); ylim([y0-d_disp y0+d_disp]);
				title('RR norm'); colorbar; %clim([-1 1])

	nexttile;	imagesc(c.c2_GR_n); axis equal tight;  hold on;
				plot(x0,y0,'+');
				for rr=10:10:d_disp
					viscircles([x0 y0], rr, 'color','k','EnhanceVisibility',0,'LineWidth',1,'LineStyle',':');
				end
				% xlim([x0-d_disp x0+d_disp]); ylim([y0-d_disp y0+d_disp]);
				title('GR norm'); colorbar; %clim([-1 1])

	nexttile;	plot(c.c1_r_all,c.c1_GR_n_all,'color',[0.8 0.8 0.8]); hold on; 
				plot(c.c1_r,c.c1_GR_n,'b'); 
				yline(0);
				xlabel('r pixel'); ylabel('corr [0,1]');
				title('GR radial');
                
	nexttile;	plot(c.c1_r,c.c1_GG_n,'g');  hold on; 
				plot(c.c1_r,c.c1_RR_n,'r');
				plot(c.c1_r,c.c1_GR_n,'b');
                yline(0);
				xlabel('r pixel'); ylabel('corr [0,1]');
				% lgd = legend(['GG: ' num2str(c.decay_GG_n)], ['RR: ' num2str(c.decay_RR_n)], ['GR: ' num2str(c.decay_GR_n)]); 
				% 	lgd.Layout.Tile = 'east';
					% title(lgd,'norm decay length [px]');
				title('radial');

%% row 4: subtracted results and gaussian fit   
	nexttile;	plot(c.c1_r, c.c1_GR,'b');  hold on; 
				plot(c.c1_r, c.c1_GR_rand,'k');
				plot(c.c1_r, c.c1_GR_sub,'g');
				yline(0);
				xlabel('r pixel'); ylabel('corr [0,1]'); 
				title('GR radial - subtracted');
	nexttile;	plot(c.c1_r, c.c1_GR_n,'b');  hold on; 
				plot(c.c1_r, c.c1_GR_rand_n,'k');
				plot(c.c1_r, c.c1_GR_sub_n,'g');
				yline(0);
				xlabel('r pixel'); ylabel('corr [0,1]'); 
				title('GR radial (norm) - subtracted');

	%% setting figure size
	figureSetting(fh,[1400 800]);
end