function fig2png(fh, filepath, filename)
% input:
% fh - figure handle
% filepath and filename of the output file
	set(fh, 'InvertHardCopy', 'off'); 
	fn_full = [filepath '\' filename];
	saveas(fh,fn_full,'png');
end