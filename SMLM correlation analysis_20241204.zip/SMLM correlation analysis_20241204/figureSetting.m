function figureSetting(fh, fig_size, fig_title)
	if nargin<3
		fig_title = [];
	end
	if nargin<2
		fig_size = [];
	end
	if ~isempty(fig_title)
		sgtitle(fig_title,'color','blue');
	end
	if ~isempty(fig_size)
		set(fh,'position',[0 0 fig_size]);
	end

	movegui(fh,"center");
end