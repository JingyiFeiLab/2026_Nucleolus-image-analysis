function [r_unique,c_unique_mean, r_all, c_all] = corr_2Dto1D(cXY, showplot)
% This function turns 2D image to the radial distribution of the image,
% asuming the dead middle of the image is the center (whether on pixel or
% 1/2 shifted)
% Author: Isaac Li
% version: 20241204 - changed the radial distribution output range such
% that it would only output areas that can be covered by full circle (i.e.
% r<=min(size(image))/2, removed the original random 100 pixel random
% definition so the function is more universal.
	if nargin<2
		showplot = 1;
	end
	% this function convers 2D correlation function to 1 D scatter plot
	% within 100 pixel distance only.
	% x0 = size(cXY,2)/2;
	% y0 = size(cXY,1)/2;
	x0 = (size(cXY,2)+1)/2; % if image is 5 pixels, center is 3 (1+5)/2, if image has 6 pixels, center is 3.5 (1+6)/2
	y0 = (size(cXY,1)+1)/2;

	[X,Y] = meshgrid(1:size(cXY,2),1:size(cXY,1));
	d2 = sqrt((X-x0).^2 + (Y-y0).^2);

	d = d2(:);
	cXY1 = cXY(:);

	[d, d_idx] = sort(d);
	cXY1 = cXY1(d_idx);

	r_limit = min(size(cXY))/2;

	r_all = d(d<r_limit);
	c_all = cXY1(d<r_limit);


	% method 1
	[r_unique, ~, ic] = unique(r_all);
	c_unique_mean = zeros(size(r_unique));
	for i = 1:length(r_unique)
    	idx = find(r_all == r_unique(i));
    	c_unique_mean(i) = mean(c_all(idx));
	end

	% method 2:
	% r100_unique = 0:1:r_limit;
	% for i = 1:length(r100_unique)-1
	% 	select_r = d>=r100_unique(i) & d<r100_unique(i+1);
	% 	c100_unique_mean(i) = mean(c100(select_r));
	% end
	% r100_unique = (r100_unique(1:end-1) + r100_unique(2:end))/2;

	% plotting
	if showplot
		figure; tiledlayout('flow')
		nexttile; imagesc(cXY); hold on; plot(x0,y0,'o'); axis equal tight;
		nexttile; imagesc(d2); hold on; plot(x0,y0,'o'); axis equal tight;
		nexttile; plot(r_all,c_all,'color',[0.8 0.8 0.8]); hold on; plot(r_unique,c_unique_mean,'r'); 
	end
end