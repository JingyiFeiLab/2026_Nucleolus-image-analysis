function MOC = manders(image1,image2) %Manders Overlap Coefficient
% Shawn first implementation
	% this double conversion was missing causing errors
	image1 = double(image1);
	image2 = double(image2);
    data1		= reshape(image1,1,[]);
    data2		= reshape(image2,1,[]);
    numerator	= sum( (data1) .* (data2) );
    denominator = sqrt( sum( (data1).^2 ) * sum( (data2).^2 ) );
    MOC			= numerator/denominator;
end