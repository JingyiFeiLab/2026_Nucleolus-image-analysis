function c = twoChannelCrossCorrelation(I_G, I_R)
    % re-normalize I_G and I_R as max = 1 grayscale
        I_G = mat2gray(I_G);
        I_R = mat2gray(I_R);
    
        I_G = imadjust(I_G, [0 1]);
        I_R = imadjust(I_R, [0 1]);

	% creating pixel randomized images
		[rows, cols] = size(I_G);
		I_G1 = I_G(:);
		rand_order = randperm(length(I_G1));
		I_G1_shuffled = I_G1(rand_order);
		I_G_rand = reshape(I_G1_shuffled, [rows, cols]);

		I_R1 = I_R(:);
		rand_order = randperm(length(I_R1));
		I_R1_shuffled = I_R1(rand_order);
		I_R_rand = reshape(I_R1_shuffled, [rows, cols]);

	% load up raw images as part of return.
		c.I_G = I_G;
		c.I_R = I_R;
		c.I_G_rand = I_G_rand;
		c.I_R_rand = I_R_rand;


    % compute normalization matrix for xcorr2
        I1s = ones(size(I_G));
        c.c2_norm = xcorr2(I1s,I1s);  % this is all 1 matrix's xcorr2 to create the normalization factor matrix of pixel number overlap.

	% xcorr2 and normxcorr2
		c.c2_GG = xcorr2(I_G, I_G);
		c.c2_RR = xcorr2(I_R, I_R);
		c.c2_GR = xcorr2(I_G, I_R);
		c.c2_GR_rand = (xcorr2(I_G, I_R_rand) + xcorr2(I_G_rand, I_R))/2;

        %note: normxcorr2 normalizes images first, creating negative values
        %before cross-correlation
		% c.c2_GG_n = normxcorr2(I_G, I_G);
		% c.c2_RR_n = normxcorr2(I_R, I_R);
		% c.c2_GR_n = normxcorr2(I_R, I_G);	% note flip R and G to match xcorr2 result

        % these normalization simply normalizes by c2_norm - the better method
        c.c2_GG_n = c.c2_GG./c.c2_norm;
		c.c2_RR_n = c.c2_RR./c.c2_norm;
		c.c2_GR_n = c.c2_GR./c.c2_norm;
		c.c2_GR_rand_n = c.c2_GR_rand./c.c2_norm;
        
	% generating distance correlation from 2D cross correlation
		[c.c1_r,c.c1_GG]	= corr_2Dto1D(c.c2_GG,0);
		[~,c.c1_RR]			= corr_2Dto1D(c.c2_RR,0);
		[~,c.c1_GR, c.c1_r_all, c.c1_GR_all] = corr_2Dto1D(c.c2_GR,0);
		[~,c.c1_GR_rand]	= corr_2Dto1D(c.c2_GR_rand,0);
		c.c1_GR_sub = c.c1_GR - c.c1_GR_rand;

		[~,c.c1_GG_n]		= corr_2Dto1D(c.c2_GG_n,0);
		[~,c.c1_RR_n]		= corr_2Dto1D(c.c2_RR_n,0);
		[~,c.c1_GR_n, ~, c.c1_GR_n_all] = corr_2Dto1D(c.c2_GR_n,0);
		[~,c.c1_GR_rand_n]	= corr_2Dto1D(c.c2_GR_rand_n,0);
		c.c1_GR_sub_n = c.c1_GR_n - c.c1_GR_rand_n;

	% pearson/manders correlation coeff
		c.pearson = pearson(I_G,I_R);
		c.manders = manders(I_G,I_R);

	% if need to plot:
		% twoChannelCrossCorrelation_plot(c, I_G, I_R);
end
