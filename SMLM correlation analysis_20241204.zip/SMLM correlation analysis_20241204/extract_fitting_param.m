% extract gaussion fitting paramter to a single file
k=1;
for i = 3:7 %change the start and end number
    filename = sprintf('1107_2_FC_ab_DFC_ab_GG_%d_fit.mat', i); % change the general file name here.
    load(filename)
    for m = 1:length(c_fit)
        gauss_coeff(k).imageID = i; %first column is image ID.
        gauss_coeff(k).objectID = m; %second column is object ID.
%         gauss_coeff(k).RR_center = c_fit(m).gauss1_coeff_RR(2); % center of RR autocorrelation.
%         gauss_coeff(k).RR_width = c_fit(m).gauss1_coeff_RR(3); % witdh of RR autocorrelation.
%         gauss_coeff(k).GG_center = c_fit(m).gauss1_coeff_GG(2); % center of GG autocorrelation.
%         gauss_coeff(k).GG_width = c_fit(m).gauss1_coeff_GG(3); % witdh of GG autocorrelation.
        gauss_coeff(k).GR_center = c_fit(m).gauss1_coeff_GRsub(2); % center of RR autocorrelation.
        gauss_coeff(k).GR_width = c_fit(m).gauss1_coeff_GRsub(3); % witdh of RR autocorrelation.
        k=k+1;
    end
end
gauss_table = struct2table(gauss_coeff); % convert to table 
writetable(gauss_table, '1107_2_FC_ab_DFC_ab_GG_gauss_coeff.csv');