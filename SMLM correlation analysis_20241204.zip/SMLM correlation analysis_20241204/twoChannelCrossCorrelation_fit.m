function [c_fit, fh] = twoChannelCrossCorrelation_fit(c,fit_range)
	if nargin<2
		fit_range.GG = [0 max(c.c1_r)];
		fit_range.RR = [0 max(c.c1_r)];
		fit_range.GR = [0 max(c.c1_r)];
	end
	fit_index.GG = c.c1_r >= fit_range.GG(1) & c.c1_r <= fit_range.GG(2);
	fit_index.RR = c.c1_r >= fit_range.RR(1) & c.c1_r <= fit_range.RR(2);
	fit_index.GR = c.c1_r >= fit_range.GR(1) & c.c1_r <= fit_range.GR(2);

% Jingyi - this is where you can write your own function to fit the
    % normalized correlation curves.
    % the x, and y values for curve fits are:
    % for GR correlation: c.c1_GR_n_r and c.c1_GR_n
    % for GG correlation: c.c1_GG_n_r and c.c1_GG_n
    % for RR correlation: c.c1_RR_n_r and c.c1_RR_n
	% example: computing 1-exp decay length
		%% for non-normalized 1D xcorr
		% guess = [max(c.c1_GG) 1 0]; % [a b c] in: y = a*exp(-bx)+c - check data to determine a useful initial guess
		% fit_result_GG = fitExpDecay(c.c1_r,c.c1_GG,guess);	% [a b c] in y = a*exp(-bx)+c
		% fit_result_RR = fitExpDecay(c.c1_r,c.c1_RR,guess);	% [a b c] in y = a*exp(-bx)+c
		% fit_result_GR = fitExpDecay(c.c1_r,c.c1_GR,guess);	% [a b c] in y = a*exp(-bx)+c
		% c_fit.decay_GG = 1/fit_result_GG(2); % [pixel] decay length
		% c_fit.decay_RR = 1/fit_result_RR(2); % [pixel] decay length
		% c_fit.decay_GR = 1/fit_result_GR(2); % [pixel] decay length

		%% for normalized 1D xcorr
		% guess = [1 1 0]; % [a b c] in: y = a*exp(-bx)+c
		% fit_result_GG_n = fitExpDecay(c.c1_r,c.c1_GG_n,guess);	% [a b c] in y = a*exp(-bx)+c
		% fit_result_RR_n = fitExpDecay(c.c1_r,c.c1_RR_n,guess);	% [a b c] in y = a*exp(-bx)+c
		% fit_result_GR_n = fitExpDecay(c.c1_r,c.c1_GR_n,guess);	% [a b c] in y = a*exp(-bx)+c
		% c_fit.decay_GG_n = 1/fit_result_GG_n(2); % [pixel] decay length
		% c_fit.decay_RR_n = 1/fit_result_RR_n(2); % [pixel] decay length
		% c_fit.decay_GR_n = 1/fit_result_GR_n(2); % [pixel] decay length

		%% for 1D xcorr, Gaussian fitting updated by Jingyi
		%guess = [1 1 0]; % [a b c] in: y = a*exp(-bx)+c
		% fitting to non-normalized correlation
		
        %jingyi disabled
		opts = fitoptions( 'Method', 'NonlinearLeastSquares' ); 
		opts.Display = 'Off';
%  		opts.Upper = [inf max(c.c1_r) max(c.c1_r)*2]; %for regular RG correlation
        opts.Upper = [inf 0 max(c.c1_r)];
        % for cross-correlation fitting to RR or GG, the center can be artifically fit to a non-zero value, better constrain "b"
		opts.Lower = [-5 0 0];
% 		opts.StartPoint = [0 0 1];

 		c_fit.gauss1_fitresult_GG = fit(c.c1_r(fit_index.GG), c.c1_GG(fit_index.GG),'gauss1',opts);	%  a1*exp(-((x-b1)/c1)^2)
 		c_fit.gauss1_fitresult_RR = fit(c.c1_r(fit_index.RR), c.c1_RR(fit_index.RR),'gauss1',opts);	% a1*exp(-((x-b1)/c1)^2)
 		c_fit.gauss1_fitresult_GRsub = fit(c.c1_r(fit_index.GR), c.c1_GR_sub(fit_index.GR),'gauss1',opts);	% a1*exp(-((x-b1)/c1)^2)

%         c_fit.gauss1_fitresult_GG = fit(c.c1_r(fit_index.GG), c.c1_GG(fit_index.GG),'gauss1');	%  a1*exp(-((x-b1)/c1)^2)
% 		c_fit.gauss1_fitresult_RR = fit(c.c1_r(fit_index.RR), c.c1_RR(fit_index.RR),'gauss1');	% a1*exp(-((x-b1)/c1)^2)
% 		c_fit.gauss1_fitresult_GRsub = fit(c.c1_r(fit_index.GR), c.c1_GR_sub(fit_index.GR),'gauss1');	% a1*exp(-((x-b1)/c1)^2)

        c_fit.gauss1_coeff_GG = coeffvalues(c_fit.gauss1_fitresult_GG);
        c_fit.gauss1_coeff_RR = coeffvalues(c_fit.gauss1_fitresult_RR);
        c_fit.gauss1_coeff_GRsub = coeffvalues(c_fit.gauss1_fitresult_GRsub);
		% c_fit.gauss_C_GG = c.gauss1_coeff_GG(2); % Gaussian center
        % c_fit.gauss_W_GG = c.gauss1_coeff_GG(3); % Gaussian width
		% c_fit.gauss_C_RR = c.gauss1_coeff_RR(2); % Gaussian center
        % c_fit.gauss_W_RR = c.gauss1_coeff_RR(3); % Gaussian width
        % c_fit.gauss_C_GR = c.gauss1_coeff_GR(2); % Gaussian center
        % c_fit.gauss_W_GR = c.gauss1_coeff_GR(3); % Gaussian width

		% %% for normalized 1D xcorr, Gaussian fitting updated by Jingyi
		% opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
		% opts.Display = 'Off';
		% opts.Upper = [inf max(c.c1_r) max(c.c1_r)*2];
		% opts.Lower = [0 0 0];
		% opts.StartPoint = [1 0 1];

		% c_fit.gauss1_fitresult_GG_n = fit(c.c1_r(fit_index.GG),c.c1_GG_n(fit_index.GG),'gauss1',opts);	%  a1*exp(-((x-b1)/c1)^2)
		% c_fit.gauss1_fitresult_RR_n = fit(c.c1_r(fit_index.RR),c.c1_RR_n(fit_index.RR),'gauss1',opts);	% a1*exp(-((x-b1)/c1)^2)
		% c_fit.gauss1_fitresult_GRsub_n = fit(c.c1_r(fit_index.GR),c.c1_GR_sub_n(fit_index.GR),'gauss1',opts);	% a1*exp(-((x-b1)/c1)^2)
        % c_fit.gauss1_coeff_GG_n = coeffvalues(c_fit.gauss1_fitresult_GG_n);
        % c_fit.gauss1_coeff_RR_n = coeffvalues(c_fit.gauss1_fitresult_RR_n);
        % c_fit.gauss1_coeff_GRsub_n = coeffvalues(c_fit.gauss1_fitresult_GRsub_n);
		% % c_fit.gauss_C_GG_n = c.gauss1_coeff_GG_n(2); % Gaussian center
        % % c_fit.gauss_W_GG_n = c.gauss1_coeff_GG_n(3); % Gaussian width
		% % c_fit.gauss_C_RR_n = c.gauss1_coeff_RR_n(2); % Gaussian center
        % % c_fit.gauss_W_RR_n = c.gauss1_coeff_RR_n(3); % Gaussian width
        % % c_fit.gauss_C_GR_n = c.gauss1_coeff_GR_n(2); % Gaussian center
        % % c_fit.gauss_W_GR_n = c.gauss1_coeff_GR_n(3); % Gaussian width


	fh = figure; 
	tiledlayout('flow','TileSpacing','tight','Padding','tight');
	nexttile;	plot(c.c1_r, c.c1_GG,'g.'); hold on;
				plot(c.c1_r(fit_index.GG), c.c1_GG(fit_index.GG),'go','MarkerFaceColor','g');
				plot(c_fit.gauss1_fitresult_GG,'g');
				
				plot(c.c1_r, c.c1_RR,'r.'); hold on;
				plot(c_fit.gauss1_fitresult_RR,'r');
				plot(c.c1_r(fit_index.RR), c.c1_RR(fit_index.RR),'ro','MarkerFaceColor','r');
				
				plot(c.c1_r, c.c1_GR_sub,'b.'); hold on;
				plot(c_fit.gauss1_fitresult_GRsub,'b');
				plot(c.c1_r(fit_index.GR), c.c1_GR_sub(fit_index.GR),'bo','MarkerFaceColor','b');

				yline(0);
				xlabel('r pixel'); ylabel('corr [0,1]'); 
				title('GR radial - subtracted');

	% nexttile;	plot(c.c1_r, c.c1_GG_n,'g.'); hold on;
			% 	plot(c.c1_r(fit_index.GG), c.c1_GG_n(fit_index.GG),'go','MarkerFaceColor','g');
			% 	plot(c_fit.gauss1_fitresult_GG_n,'g');
    % 
			% 	plot(c.c1_r, c.c1_RR_n,'r.'); hold on;
			% 	plot(c_fit.gauss1_fitresult_RR_n,'r');
			% 	plot(c.c1_r(fit_index.RR), c.c1_RR_n(fit_index.RR),'ro','MarkerFaceColor','r');
    % 
			% 	plot(c.c1_r, c.c1_GR_sub_n,'b.'); hold on;
			% 	plot(c_fit.gauss1_fitresult_GRsub_n,'b');
			% 	plot(c.c1_r(fit_index.GR), c.c1_GR_sub_n(fit_index.GR),'bo','MarkerFaceColor','b');
    % 
			% 	yline(0);
			% 	xlabel('r pixel'); ylabel('corr [0,1]'); 
			% 	title('GR radial (norm) - subtracted');
	figureSetting(fh,[1400 800]);
end