% extract gaussion fitting paramter to a single file
k=1;
for i = 1:7 %change the start and end number
    filename = sprintf('1118_4_FC_ab_DFC_biotin_RR_%d_Gauss2_fit.mat', i); % change the general file name here.
    load(filename)
    for m = 1:length(c_fit)
        gauss2_coeff(k).imageID = i; %first column is image ID.
        gauss2_coeff(k).objectID = m; %second column is object ID.
        gauss2_coeff(k).P1_width = min(c_fit(m).gauss2_coeff_GRsub(3), c_fit(m).gauss2_coeff_GRsub(6)); % width of the first peak
        gauss2_coeff(k).P2_width = max(c_fit(m).gauss2_coeff_GRsub(3), c_fit(m).gauss2_coeff_GRsub(6)); % width of the second peak
        k=k+1;
    end
end
gauss_table = struct2table(gauss2_coeff); % convert to table 
writetable(gauss_table, '20241118_4_FC_ab_DFC_biotin_RR_Gau2_coeff_2.csv');