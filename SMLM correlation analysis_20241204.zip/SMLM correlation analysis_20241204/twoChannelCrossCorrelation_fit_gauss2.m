function [c_fit, fh] = twoChannelCrossCorrelation_fit_gauss2(c,fit_range)
	if nargin<2
		fit_range.GG = [0 max(c.c1_r)];
		fit_range.RR = [0 max(c.c1_r)];
		fit_range.GR = [0 max(c.c1_r)];
	end
	fit_index.GG = c.c1_r >= fit_range.GG(1) & c.c1_r <= fit_range.GG(2);
	fit_index.RR = c.c1_r >= fit_range.RR(1) & c.c1_r <= fit_range.RR(2);
	fit_index.GR = c.c1_r >= fit_range.GR(1) & c.c1_r <= fit_range.GR(2);
		

		opts = fitoptions( 'Method', 'NonlinearLeastSquares' ); 
		opts.Display = 'Off';
%  		opts.Upper = [inf max(c.c1_r) max(c.c1_r)*2]; %for regular RG correlation
        opts.Upper = [inf 0 10 inf 0 max(c.c1_r)]; % for Gauss2 fitting
        % for cross-correlation fitting to RR or GG, the center can be artifically fit to a non-zero value, better constrain "b"
        % opts.Lower = [-5 0 0]; % for Gauss1 fitting
		opts.Lower = [max(c.c1_GR_sub)*0.1 0 1 max(c.c1_GR_sub)*0.1 0 2]; % for Gauss2 fitting
% 		opts.StartPoint = [0 0 1];

 		c_fit.gauss2_fitresult_GRsub = fit(c.c1_r(fit_index.GR), c.c1_GR_sub(fit_index.GR),'gauss2',opts);	% a1*exp(-((x-b1)/c1)^2)
        
        c_fit.gauss2_coeff_GRsub = coeffvalues(c_fit.gauss2_fitresult_GRsub);

	fh = figure; 
	tiledlayout('flow','TileSpacing','tight','Padding','tight');
	nexttile;	plot(c.c1_r, c.c1_GR_sub,'b.'); hold on;
				plot(c_fit.gauss2_fitresult_GRsub,'b');
				plot(c.c1_r(fit_index.GR), c.c1_GR_sub(fit_index.GR),'bo','MarkerFaceColor','b');

				yline(0);
				xlabel('r pixel'); ylabel('corr [0,1]'); 
				title('GR radial - subtracted');

	figureSetting(fh,[1400 800]);
end