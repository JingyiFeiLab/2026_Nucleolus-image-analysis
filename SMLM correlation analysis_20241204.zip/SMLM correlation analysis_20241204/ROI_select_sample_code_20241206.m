%% file dependency list
	filedep = matlab.codetools.requiredFilesAndProducts('ROI_select_sample_code_JF_20241206.m');
	for i=1:length(filedep)
		fprintf('%s\r',filedep{i})
	end

%% STEP 1: ROI SELECTION 
clear all
close all

% reading R and G images (raw format can be whatever you use, just make
% sure imgG is the green channel and imgR is the red channel.
	fp = 'C:\Users\anast\OneDrive - The University of Chicago\Data\Nucleoli-seq\STORM image\20241211 STORM_DFC_ab_DFC_biotin\21';
    fn_G = '4%_DFC_ab_biotin_epi_21G_T3_F40_x+8y+3.tif';
    fn_R = '4%_DFC_ab_biotin_epi_21R_T3_F40.tif';

	imgG = imread([fp '\' fn_G]);
	imgR = imread([fp '\' fn_R]);

    imgG = mat2gray(imgG);
    imgR = mat2gray(imgR);

    imgG = imadjust(imgG, [0 1]);
    imgR = imadjust(imgR, [0 1]);

% creating a composit color image (img3) for display purpose only
	img3(:,:,1) = imadjust(imgR);
	img3(:,:,2) = imadjust(imgG);
	img3(:,:,3) = zeros(size(imgG));

% creating output folder based on when this code is ran
	ymdtime = datestr(datetime('now'), 'yyyy-mm-dd_HH-MM-SS');
	fp_roi = sprintf('%s\\roi_%s',fp,ymdtime);
	mkdir(fp_roi);

% =================== MAIN FUNCTION FOR SELECTING ROIS ====================
	ROIs = ROI_select(img3,fp_roi);
% =========================================================================

% exporting G and R ROIs to fp_roi folder, all ROI would have the same file
% name as the full size images and with _0##.tif as indices.
	[~,fn_base_G] = fileparts(fn_G);
	[~,fn_base_R] = fileparts(fn_R);
	ROI_export(imgG, ROIs, fp_roi, fn_base_G);
	ROI_export(imgR, ROIs, fp_roi, fn_base_R);



%% STEP 2: INDIVIDUAL ROI CORRELATION ANALYSIS

 fp_roi = 'C:\Users\Jingyi\OneDrive - The University of Chicago\Data\Nucleoli-seq\STORM image\20241109 STORM DFC_ab_DFC_ab\1107_4_DFC_ab_DFC_ab_5_roi_2024-11-27';
 % disable the above line if you are running the code in one step
% fp_roi = 'D:\OneDrive - UBC\UBC-Data\Current Members\Collaboration\Jingyi Fei\2024-11-28 - correlation sample\roi_2024-12-03_22-47-09';
% gathering list of filenames for G and R channels. same index should be
% the same pair.fp_roi = 'D:\OneDrive - UBC\UBC-Data\Current Members\Collaboration\Jingyi Fei\2024-06-19 - correlation distance (images)\positive example';
	fn_G = filelist(fp_roi, '1107_4_DFC_ab_DFC_ab_5R_T3_F40_*.tif');
	fn_R = filelist(fp_roi, '1107_4_DFC_ab_DFC_ab_5R_T3_F40_*.tif');

% some basic error handling, the number of G and R images should be same
	if length(fn_G) == length(fn_R)
		N_img = length(fn_G);
	else
		error('# of Red and Green images unequal, check!');
	end

% go through each pair and perform twoChannelCrossCorrelation
for i=1:N_img
	I_G = imread([fp_roi '\' fn_G{i}]);
	I_R = imread([fp_roi '\' fn_R{i}]);

	% step 1: run the correlation
	c(i) = twoChannelCrossCorrelation(I_G, I_R);

	% step 2(optional): visual inspect all data
	fh = twoChannelCrossCorrelation_plot(c(i));
	fp_cc = [fp_roi '\correlation result'];
	mkdir(fp_cc);
	fn_cc = sprintf('cc_ROI_%03d.png',i);
	fig2png(fh,fp_cc,fn_cc);
end

%% STEP 3: RUNNING FITTING
    fp_roi = 'C:\Users\anast\OneDrive - The University of Chicago\Data\Nucleoli-seq\STORM image\20241118_STORM FC_ab_DFC_biotin\RR';
% disable the above line if you are running the code in one step.
for i=1:N_img
	fit_range.GG = [0 max(c(1).c1_r)*0.1];
	fit_range.RR = [0 max(c(1).c1_r)*0.1];
	fit_range.GR = [0 max(c(1).c1_r)*0.5];
%  	[c_fit(i), fh] = twoChannelCrossCorrelation_fit(c(i),fit_range);
     [c_fit(i), fh] = twoChannelCrossCorrelation_fit_gauss2(c(i),fit_range);
%     [c_fit(i), fh] = twoChannelCrossCorrelation_fit_decay1(c(i),fit_range);
	fp_cfit = [fp_roi '\fitting result'];
	mkdir(fp_cfit);
	fn_cfit = sprintf('c_fit_ROI_%03d.png',i);
	fig2png(fh,fp_cfit,fn_cfit);
end

