function ROIs = ROI_select(img, fp)
	fh = figure('Position',[100 100 1600 800]); movegui(fh,"center"); 
	th = tiledlayout(1,2,'Padding','compact');
	ax1 = nexttile(th,1); imshow(img); title('original img');
	ax2 = nexttile(th,2); imshow(img); title('current ROI zoom in');
	
	ROIs = [];
	roi_count = 0;
	
	h = msgbox('Instruction: Draw rectangular ROIs, press "ENTER" or DOUBLE-CLICK to confirm ROI.');
	waitfor(h);
	
	while true
		r = drawrectangle(ax1,'LineWidth',1);
		addlistener(r, 'MovingROI', @(src, evt) roiMovedCallback(src,img,th));
		% addlistener(r, 'ROIMoved', @(src, evt) roiMovedCallback(src,img3,th));
		addlistener(r, 'ROIClicked', @(src, evt) roiMovedCallback(src,img,th));
		wait(r);
	
		pos					= round(r.Position);
    	roi_count			= roi_count + 1;
    	ROIs(roi_count).id	= roi_count;
		ROIs(roi_count).pos = pos;
		drawrectangle(ax1, 'Position',pos,'Color',[1 0 1],'Label',num2str(roi_count),'LabelAlpha',0.7,'FaceAlpha',0,'LineWidth',1, 'InteractionsAllowed','none','LabelTextColor','w');	
		fprintf('ROI %d: x = %d, y = %d, w = %d, h = %d\n', roi_count, pos(1), pos(2), pos(3), pos(4));
		delete(r);
	
    	choice = questdlg('Add new ROI?', 'Add new ROI', 'Yes', 'No', 'Yes');
		if strcmp(choice, 'No')
			break;
		end
	end
	
	% Display ROI positions
	fprintf('\r--------------------------------\r');
	for i = 1:roi_count
    	fprintf('ROI %d: x = %d, y = %d, w = %d, h = %d\n', ROIs(i).id, ROIs(i).pos(1), ROIs(i).pos(2), ROIs(i).pos(3), ROIs(i).pos(4));
	end

	if ~exist(fp)
		mkdir(fp);
	end
	fn_out_png = [fp '\ROI_selection.png'];
	fn_out_fig = [fp '\ROI_selection.fig'];
	fprintf('\rROI_select: exporting ROI seletion image to: %s\r',fn_out_png)
	exportgraphics(ax1,fn_out_png);
	saveas(ax1,fn_out_fig);
end




function roiMovedCallback(src,img,th)
    roi_pos = round(src.Position);
	image_roi = imcrop(img,roi_pos);
	nexttile(th,2); 
		imshow(image_roi);  
		title(['current ROI [x y w h]: ' mat2str(roi_pos)]);
end