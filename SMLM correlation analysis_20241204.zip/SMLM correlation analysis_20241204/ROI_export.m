function ROI_export(img, ROIs, fp, fn_base)
	if exist(fp)
		fprintf('ROI_export: overwriting everything in directory: %s\r',fp);
	else
		fprintf('ROI_export: create directory: %s\r',fp);
		mkdir(fp);
	end
	% exporting ROI images
	for i = 1:length(ROIs)
		imgR_roi = imcrop(img,ROIs(i).pos);
		fn_full = sprintf('%s\\%s_%03d.tif',fp,fn_base,i);
		disp(fn_full);
		imwrite(imgR_roi,fn_full);
	end
end